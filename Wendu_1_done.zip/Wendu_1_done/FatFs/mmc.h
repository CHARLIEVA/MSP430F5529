uint8_t detectCard(void);
