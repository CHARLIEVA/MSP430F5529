
#ifndef WENDU_1_LAB7_H_
#define WENDU_1_LAB7_H_


extern void readDS18B20andDisplay(void);

#endif /* WENDU_1_LAB7_H_ */
